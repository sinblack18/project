from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader

from django.core.paginator import Paginator
from .models import Board

# Create your views here.
# views.py의 함수에 들어있는 request 파라미터 : 요청객체


# 게시판 목록보기
def index(request):
    print('index() 실행')

    result = None

    context = {}

    # request.GET : GET 방식으로 보낸 데이터들을 딕셔너리 타입으로 저장
    # print(request.GET)

    # 검색 조건과 검색 키워드가 있어야 필터링 실행
    if 'searchType' in request.GET and 'searchWord' in request.GET:
        search_type = request.GET['searchType']  # GET 안의 문자열은
        search_word = request.GET['searchWord']  # HTML의 name 속성

        print("search_type : {}, search_word : {}".format(
            search_type, search_word))

        # match : Java의 switch랑 비슷함
        match search_type:
            case 'title':  # 검색 기준이 제목일 때
                result = Board.objects.filter(title1__contains=search_word)
            case 'writer':  # 검색 기준이 글쓴이일 때
                result = Board.objects.filter(writer__contains=search_word)
            case 'content':  # 검색 기준이 내용일 때
                result = Board.objects.filter(content__contains=search_word)

        # 검색을 했을때만 검색 기준과 키워드를 context에 넣는다
        context['searchType'] = search_type
        context['searchWord'] = search_word

    else:  # QueryDict에 검색 조건에 키워드가 없을 때
        result = Board.objects.all()

    # 검색 결과 또는 전체 목록을 id의 내림차순 정렬
    result = result.order_by('-id')

    # 페이징 넣기
    # Paginator(목록, 목록에 보여줄 개수)
    paginator = Paginator(result, 10)

    # Paginator 클래스를 이용해서 자른 목록의 단위에서
    # 몇번째 단위를 보여줄 것인지 정한다
    page_obj = paginator.get_page(request.GET.get('page'))

    # context['board_list'] = result
    # 페이징한 일부 목록 반환
    context['page_obj'] = page_obj

    return render(request, 'board/index.html', context)


def read(request, id):

    print(id)

    board = Board.objects.get(id=id)

    # 조회수 올리기
    board.view_count += 1
    board.save()

    context = {
        'board': board
    }

    return render(request, 'board/read.html', context)


def home(request):

    return HttpResponseRedirect('/board/')


def write(request):

    if request.method == 'GET':  # 요청방식이 GET이면 화면 표시
        return render(request, 'board/board_form.html')

    else:  # 요청방식이 POST일 때 할 일

        # 폼의 데이터를 DB에 저장
        title1 = request.POST['title1']
        content = request.POST['content']

        # 현재 세션정보의 writer라는 키를 가진 데이터 취득
        session_writer = request.session.get('writer')
        if not session_writer:  # 세션에 정보가 없는 경우
            # 폼에서 가져온 writer 값 세션에 저장
            request.session['writer'] = request.POST['writer']

        print(session_writer)

        # 객체.save()

        # board = Board(
        #     title1=title1,
        #     writer=writer,
        #     content=content
        # )

        # board.save()  # db에 insert

        # 모델.objects.create(값)

        Board.objects.create(
            title1=title1,
            writer=request.session.get('writer'),  # 세션에 있는 값 저장
            content=content
        )

        return HttpResponseRedirect('/board/')


def update(request, id):

    print(id)

    board = Board.objects.get(id=id)

    if request.method == "GET":

        context = {'board': board}

        return render(request, 'board/board_update.html', context)

    else:
        board.title1 = request.POST['title1']
        board.writer = request.POST['writer']
        board.content = request.POST['content']

        board.save()

        redirect_url = '/board/'+str(id) + '/'

        return HttpResponseRedirect(redirect_url)


def delete(request, id):

    print(id)
    # 해당 객체를 가져와서(get 가져올꺼니깐) 삭제
    Board.objects.get(id=id).delete()

    return HttpResponseRedirect('/board/')


# def search_board(request):

#     title1 = request.POST['search']

#     bList = Board.objects.filter(title1__contains=title1)

#     context = {
#         'board_list': bList
#     }

#     return render(request, 'board/index.html', context)
