# 장고의 기본 라이브러리
from django.urls import path

# 현재 패키지에서 views 를 import하세요
from . import views  # .은 현재 폴더에서 라는 뜻

urlpatterns = [
    # .../board/
    path('', views.index),
    path('<int:id>/', views.read),
    path('write/', views.write),
    path('<int:id>/update/', views.update),
    path('<int:id>/delete/', views.delete),
    # path('search_board/', views.search_board),
]
